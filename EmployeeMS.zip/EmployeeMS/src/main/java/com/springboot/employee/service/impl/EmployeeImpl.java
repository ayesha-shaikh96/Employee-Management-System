package com.springboot.employee.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.employee.entity.Employee;
import com.springboot.employee.repository.EmployeeRepository;
import com.springboot.employee.service.EmployeeService;

@Service
public class EmployeeImpl implements EmployeeService
{

	private EmployeeRepository emprepo;
	
	public EmployeeImpl(EmployeeRepository emprepo) {
		super();
		this.emprepo = emprepo;
	}




	@Override
	public List<Employee> getAllEmployee() 
	{
		
		return emprepo.findAll();
	}




	@Override
	public Employee saveEmployee(Employee employee) {
		
		return emprepo.save(employee);
	}




	@Override
	public Employee getEmployeeById(int id) 
	{
		
		return emprepo.findById(id).get();
	}




	@Override
	public void deleteEmployeeById(int id) 
	{
		emprepo.deleteById(id);
		
	}

}
