package com.springboot.employee.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.springboot.employee.entity.Employee;

import com.springboot.employee.service.EmployeeService;

@Controller
public class EmployeeController
{
	
	private EmployeeService empser;

	public EmployeeController(EmployeeService empser) {
		super();
		this.empser = empser;
	}
	
	//get all users data
	
		@GetMapping("/GetEmployee")
		public String listEmployee(Model mod)
		{
			mod.addAttribute("employees",empser.getAllEmployee());
			return "employees";
		}
		
	//access Insert Form 
				@GetMapping("/Employee/New")
				public String CreateEmployee(Model mod)
				{
					Employee employee =new Employee();
					mod.addAttribute("employee", employee);
					return "create_employee";
					
				}
				
				
				//Save record into database
				@PostMapping("/Employee/save")
				public String saveUser(@ModelAttribute("employee") Employee employee)
				{
					empser.saveEmployee(employee);
					
					return "redirect:/GetEmployee";
					
				}
				
				
				
				//Get data by id
				@GetMapping("/Employee/edit/{id}")
				public String editUserForm(@PathVariable int id , Model mod)
				{
					mod.addAttribute("employee", empser.getEmployeeById(id));
					return "edit_employee";
					
				}
				
				
				
				// Update data 
				@PostMapping("/employee/update/{id}")
				public String updateEmployee(@PathVariable int id , @ModelAttribute("employee") Employee employee , Model mod)
				{
					Employee existingEmployee = empser.getEmployeeById(id);
					existingEmployee.setId(id);
					existingEmployee.setName(employee.getName());
					existingEmployee.setSalary(employee.getSalary());
					existingEmployee.setAddress(employee.getAddress());
					existingEmployee.setContact(employee.getContact());
					existingEmployee.setDesignation(employee.getDesignation());
					empser.saveEmployee(existingEmployee);
					return "redirect:/GetEmployee";
					
				}
				
				
				
				//Delete Data by id
				@GetMapping("/Employee/delete/{id}")
				public String deleteEmployee(@PathVariable int id )
				{
					empser.deleteEmployeeById(id);
					return "redirect:/GetEmployee";
					
				}
				

}
