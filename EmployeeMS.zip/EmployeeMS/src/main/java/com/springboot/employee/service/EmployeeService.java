package com.springboot.employee.service;

import java.util.List;

import com.springboot.employee.entity.Employee;



public interface EmployeeService 
{

	List<Employee> getAllEmployee();
	
	Employee saveEmployee(Employee employee);
	
	Employee getEmployeeById(int id);
	
	void deleteEmployeeById(int id);
}
